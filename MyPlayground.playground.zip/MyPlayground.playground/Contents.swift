# include〈stdio.h〉
int main()
do {
    print("hello,刘婧佩.\n");
    func 0;
}
